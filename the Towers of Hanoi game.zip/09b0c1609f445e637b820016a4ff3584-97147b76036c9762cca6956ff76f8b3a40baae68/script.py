from stack import Stack

print("\nLet's play Towers of Hanoi!!")
print("The goal is to move all disks from the Left stack to the Right stack. ")
print("Only one disk can be moved at a time, and no disk may be placed on top of a smaller disk.")

# Create the stacks
stacks = []

# Create three Stack instances 
left_stack = Stack("Left")
middle_stack = Stack("Middle")
right_stack = Stack("Right")

# Append the stacks to the list
stacks.append(left_stack)
stacks.append(middle_stack)
stacks.append(right_stack)

# Set up the Game
while True:
    try:
        num_disks = int(input("\nHow many disks do you want to play with?\n"))
        if num_disks >= 3:
            break
        else:
            print("Enter a number greater than or equal to 3")
    except ValueError:
        print("Please enter a valid integer.")

# Add disks to the left stack (largest disk = num_disks)
for disk in range(num_disks, 0, -1):
    left_stack.push(disk)

# Calculate the optimal number of moves
num_optimal_moves = 2 ** num_disks - 1
print("\nThe fastest you can solve this game is in {0} moves".format(num_optimal_moves))

# Helper function to get user input for stack selection
def get_input():
    choices = [stack.get_name()[0].upper() for stack in stacks]  # First letters of stack names

    while True:
        print("\nChoose a stack:")
        for i in range(len(stacks)):
            name = stacks[i].get_name()
            letter = choices[i]
            print("Enter {0} for {1}".format(letter, name))

        user_input = input("").upper()  # Get user input and uppercase it for consistency

        if user_input in choices:
            return stacks[choices.index(user_input)]
        else:
            print("Invalid choice. Please try again.\n")

# Main game loop
num_user_moves = 0

while right_stack.get_size() != num_disks:
    print("\n\n\n...Current Stacks...")
    for stack in stacks:
        stack.print_items()

    while True:
        print("\nWhich stack do you want to move from?\n")
        from_stack = get_input()

        print("\nWhich stack do you want to move to?\n")
        to_stack = get_input()

        if from_stack.is_empty():
            print("\n\nInvalid Move. Try Again")
        elif to_stack.is_empty() or from_stack.peek() < to_stack.peek():
            disk = from_stack.pop()
            to_stack.push(disk)
            num_user_moves += 1
            break
        else:
            print("\n\nInvalid Move. Try Again")

print("\n\nYou completed the game in {0} moves, and the optimal number of moves is {1}".format(num_user_moves, num_optimal_moves))